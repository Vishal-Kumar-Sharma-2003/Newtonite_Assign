import os
import tempfile
import unittest

from werkzeug.security import generate_password_hash

from app import create_app
from app.db import connect, tx
from app.util import utcnow

PW = "pw"


class ApiTestCase(unittest.TestCase):
    """Fresh DB per test: team A (lead_a, m1, m2, viewer_a) and team B (lead_b, outsider)."""

    def setUp(self):
        fd, self.path = tempfile.mkstemp(suffix=".db")
        os.close(fd)
        self.app = create_app(self.path)
        self.app.testing = True
        self.db = connect(self.path)
        h = generate_password_hash(PW)
        with tx(self.db):
            self.team_a = self.db.execute("INSERT INTO teams(name) VALUES ('A')").lastrowid
            self.team_b = self.db.execute("INSERT INTO teams(name) VALUES ('B')").lastrowid
            self.uid = {}
            for name, team, role in [("lead_a", "a", "lead"), ("lead_a2", "a", "lead"), ("m1", "a", "member"),
                                     ("m2", "a", "member"), ("viewer_a", "a", "viewer"),
                                     ("lead_b", "b", "lead"), ("outsider", "b", "member")]:
                self.uid[name] = self.db.execute("INSERT INTO users(username,name,password_hash) VALUES (?,?,?)",
                                                 (name, name, h)).lastrowid
                self.db.execute("INSERT INTO memberships VALUES (?,?,?)",
                                (self.uid[name], self.team_a if team == "a" else self.team_b, role))

    def tearDown(self):
        self.db.close()
        for suffix in ("", "-wal", "-shm"):
            try:
                os.remove(self.path + suffix)
            except FileNotFoundError:
                pass

    # --- helpers ---
    def login(self, username, client=None):
        c = client or self.app.test_client()
        r = c.post("/api/login", json={"username": username, "password": PW})
        self.assertEqual(r.status_code, 200)
        return {"Authorization": "Bearer " + r.get_json()["token"]}

    def make_item(self, status="open", assignee=None, team=None, priority="medium", title="t"):
        now = utcnow()
        with tx(self.db):
            return self.db.execute(
                "INSERT INTO work_items(title,description,type,priority,status,team_id,assignee_id,created_by,"
                "due_date,version,created_at,updated_at) VALUES (?, '', 'task', ?, ?, ?, ?, ?, NULL, 1, ?, ?)",
                (title, priority, status, team or self.team_a, self.uid[assignee] if assignee else None,
                 self.uid["lead_a"], now, now)).lastrowid

    def item_row(self, item_id):
        return dict(self.db.execute("SELECT * FROM work_items WHERE id=?", (item_id,)).fetchone())

    def count(self, table, where="1=1", params=()):
        return self.db.execute(f"SELECT COUNT(*) FROM {table} WHERE {where}", params).fetchone()[0]
