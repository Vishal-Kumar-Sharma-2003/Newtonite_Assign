"""Tests for the dangerous behaviours: concurrency, stale writes, retries, workflow,
authorization, atomic history, async reliability, pagination."""
import threading
import unittest
from unittest import mock

from app import items as svc, worker
from app.db import tx

from .helpers import ApiTestCase


class ConcurrentClaim(ApiTestCase):
    def test_only_one_of_many_parallel_claims_wins(self):
        item = self.make_item()
        users = ["m1", "m2", "lead_a", "lead_a2"]
        clients = [self.app.test_client() for _ in users]
        headers = [self.login(u, c) for u, c in zip(users, clients)]
        barrier, results = threading.Barrier(len(users)), []

        def go(client, h):
            barrier.wait()
            results.append(client.post(f"/api/items/{item}/claim", headers=h).status_code)

        threads = [threading.Thread(target=go, args=(c, h)) for c, h in zip(clients, headers)]
        [t.start() for t in threads]
        [t.join() for t in threads]
        self.assertEqual(sorted(results), [200, 409, 409, 409])
        row = self.item_row(item)
        self.assertEqual(row["version"], 2)  # incremented exactly once
        self.assertEqual(self.count("activity_events", "item_id=? AND kind='assignee_changed'", (item,)), 1)


class StaleUpdate(ApiTestCase):
    def test_stale_version_rejected_with_latest_and_data_unchanged(self):
        item = self.make_item()
        h1, h2 = self.login("m1"), self.login("m2")
        c = self.app.test_client()
        ok = c.patch(f"/api/items/{item}", json={"version": 1, "title": "first"}, headers=h1)
        self.assertEqual(ok.status_code, 200)
        self.assertEqual(ok.get_json()["version"], 2)
        stale = c.patch(f"/api/items/{item}", json={"version": 1, "title": "second"}, headers=h2)
        self.assertEqual(stale.status_code, 409)
        self.assertEqual(stale.get_json()["error"]["code"], "version_conflict")
        self.assertEqual(stale.get_json()["current"]["title"], "first")
        self.assertEqual(self.item_row(item)["title"], "first")
        self.assertEqual(self.item_row(item)["version"], 2)


class Idempotency(ApiTestCase):
    def test_same_key_creates_one_item_and_replays_response(self):
        h = {**self.login("m1"), "Idempotency-Key": "abc-123"}
        c = self.app.test_client()
        payload = {"team_id": self.team_a, "title": "double click"}
        r1 = c.post("/api/items", json=payload, headers=h)
        r2 = c.post("/api/items", json=payload, headers=h)
        self.assertEqual((r1.status_code, r2.status_code), (201, 201))
        self.assertEqual(r1.get_json(), r2.get_json())
        self.assertEqual(r2.headers.get("Idempotent-Replay"), "true")
        self.assertEqual(self.count("work_items", "title='double click'"), 1)

    def test_same_key_different_payload_is_rejected(self):
        h = {**self.login("m1"), "Idempotency-Key": "k1"}
        c = self.app.test_client()
        c.post("/api/items", json={"team_id": self.team_a, "title": "one"}, headers=h)
        r = c.post("/api/items", json={"team_id": self.team_a, "title": "two"}, headers=h)
        self.assertEqual(r.status_code, 422)
        self.assertEqual(self.count("work_items", "title IN ('one','two')"), 1)

    def test_parallel_retries_with_same_key_create_one_item(self):
        h = {**self.login("m1"), "Idempotency-Key": "race"}
        barrier, codes = threading.Barrier(4), []

        def go():
            c = self.app.test_client()
            barrier.wait()
            codes.append(c.post("/api/items", json={"team_id": self.team_a, "title": "race"}, headers=h).status_code)

        ts = [threading.Thread(target=go) for _ in range(4)]
        [t.start() for t in ts]
        [t.join() for t in ts]
        self.assertEqual(codes, [201] * 4)
        self.assertEqual(self.count("work_items", "title='race'"), 1)


class WorkflowRules(ApiTestCase):
    def post(self, user, item, to, version=None):
        v = version or self.item_row(item)["version"]
        return self.app.test_client().post(f"/api/items/{item}/transition", json={"to": to, "version": v},
                                           headers=self.login(user))

    def test_invalid_jump_rejected(self):
        item = self.make_item(status="open", assignee="m1")
        r = self.post("m1", item, "closed")
        self.assertEqual(r.status_code, 409)
        self.assertEqual(r.get_json()["error"]["code"], "invalid_transition")
        self.assertEqual(self.item_row(item)["status"], "open")

    def test_member_cannot_approve_but_other_lead_can(self):
        item = self.make_item(status="awaiting_approval", assignee="m1")
        self.assertEqual(self.post("m1", item, "resolved").status_code, 403)
        self.assertEqual(self.post("viewer_a", item, "resolved").status_code, 403)
        self.assertEqual(self.post("lead_a", item, "resolved").status_code, 200)

    def test_lead_cannot_approve_own_item(self):
        item = self.make_item(status="awaiting_approval", assignee="lead_a")
        r = self.post("lead_a", item, "resolved")
        self.assertEqual((r.status_code, r.get_json()["error"]["code"]), (403, "self_approval"))
        self.assertEqual(self.post("lead_a2", item, "resolved").status_code, 200)

    def test_member_can_only_move_own_items(self):
        item = self.make_item(status="in_progress", assignee="m1")
        self.assertEqual(self.post("m2", item, "awaiting_approval").status_code, 403)
        self.assertEqual(self.post("m1", item, "awaiting_approval").status_code, 200)

    def test_full_happy_path_records_history(self):
        item = self.make_item()
        c = self.app.test_client()
        self.assertEqual(c.post(f"/api/items/{item}/claim", headers=self.login("m1")).status_code, 200)
        self.assertEqual(self.post("m1", item, "awaiting_approval").status_code, 200)
        self.assertEqual(self.post("lead_a", item, "resolved").status_code, 200)
        self.assertEqual(self.post("lead_a", item, "closed").status_code, 200)
        r = c.get(f"/api/items/{item}/activity", headers=self.login("viewer_a"))
        kinds = [e["kind"] for e in r.get_json()["events"]]
        self.assertEqual(kinds.count("status_changed"), 4)   # claim + 3 transitions


class Authorization(ApiTestCase):
    def test_other_team_user_gets_403_on_read_and_every_write(self):
        item = self.make_item()
        c, h = self.app.test_client(), self.login("outsider")
        v = 1
        calls = [c.get(f"/api/items/{item}", headers=h),
                 c.get(f"/api/items/{item}/activity", headers=h),
                 c.patch(f"/api/items/{item}", json={"version": v, "title": "x"}, headers=h),
                 c.post(f"/api/items/{item}/claim", headers=h),
                 c.post(f"/api/items/{item}/transition", json={"to": "in_progress", "version": v}, headers=h),
                 c.post(f"/api/items/{item}/assign", json={"assignee_id": None, "version": v}, headers=h),
                 c.post(f"/api/items/{item}/comments", json={"body": "hi"}, headers=h)]
        self.assertEqual([r.status_code for r in calls], [403] * len(calls))
        self.assertEqual(self.item_row(item)["version"], 1)

    def test_list_only_contains_own_teams_items(self):
        self.make_item(title="team a")
        self.make_item(team=self.team_b, title="team b")
        r = self.app.test_client().get("/api/items", headers=self.login("outsider"))
        self.assertEqual([i["title"] for i in r.get_json()["items"]], ["team b"])
        r = self.app.test_client().get(f"/api/items?team_id={self.team_a}", headers=self.login("outsider"))
        self.assertEqual(r.status_code, 403)

    def test_viewer_is_read_only_and_member_cannot_reassign(self):
        item = self.make_item()
        c = self.app.test_client()
        self.assertEqual(c.post("/api/items", json={"team_id": self.team_a, "title": "x"},
                                headers=self.login("viewer_a")).status_code, 403)
        self.assertEqual(c.post(f"/api/items/{item}/comments", json={"body": "x"},
                                headers=self.login("viewer_a")).status_code, 403)
        self.assertEqual(c.post(f"/api/items/{item}/assign", json={"assignee_id": self.uid["m2"], "version": 1},
                                headers=self.login("m1")).status_code, 403)
        self.assertEqual(c.post(f"/api/items/{item}/assign", json={"assignee_id": self.uid["m2"], "version": 1},
                                headers=self.login("lead_a")).status_code, 200)

    def test_assignee_must_belong_to_team(self):
        item = self.make_item()
        r = self.app.test_client().post(f"/api/items/{item}/assign",
                                        json={"assignee_id": self.uid["outsider"], "version": 1},
                                        headers=self.login("lead_a"))
        self.assertEqual(r.status_code, 422)

    def test_requires_login(self):
        c = self.app.test_client()
        self.assertEqual(c.get("/api/items").status_code, 401)
        self.assertEqual(c.post("/api/login", json={"username": "m1", "password": "wrong"}).status_code, 401)


class AtomicHistory(ApiTestCase):
    def test_failure_after_update_rolls_back_item_event_and_job(self):
        item = self.make_item()
        h = self.login("lead_a")
        with mock.patch.object(svc, "enqueue", side_effect=RuntimeError("boom")):
            with self.assertRaises(RuntimeError):
                self.app.test_client().post(f"/api/items/{item}/assign",
                                            json={"assignee_id": self.uid["m1"], "version": 1}, headers=h)
        row = self.item_row(item)
        self.assertEqual((row["assignee_id"], row["version"]), (None, 1))
        self.assertEqual(self.count("activity_events", "item_id=?", (item,)), 0)
        self.assertEqual(self.count("outbox"), 0)


class OutboxWorker(ApiTestCase):
    def test_job_processed_twice_yields_one_notification(self):
        item = self.make_item()
        r = self.app.test_client().post(f"/api/items/{item}/assign",
                                        json={"assignee_id": self.uid["m1"], "version": 1},
                                        headers=self.login("lead_a"))
        self.assertEqual(r.status_code, 200)
        self.assertEqual(self.count("outbox", "status='pending'"), 1)
        self.assertEqual(worker.run_once(self.db), 1)
        self.assertEqual(worker.run_once(self.db), 0)
        with tx(self.db):   # simulate duplicate delivery (e.g. worker crashed before marking done)
            self.db.execute("UPDATE outbox SET status='pending', next_attempt_at=0")
        worker.run_once(self.db)
        self.assertEqual(self.count("notifications", "user_id=?", (self.uid["m1"],)), 1)

    def test_approval_request_notifies_leads(self):
        item = self.make_item(status="in_progress", assignee="m1")
        self.app.test_client().post(f"/api/items/{item}/transition",
                                    json={"to": "awaiting_approval", "version": 1}, headers=self.login("m1"))
        worker.run_once(self.db)
        notified = {r[0] for r in self.db.execute("SELECT user_id FROM notifications")}
        self.assertEqual(notified, {self.uid["lead_a"], self.uid["lead_a2"]})

    def test_failing_job_retries_with_backoff_then_is_marked_failed(self):
        def boom(conn, job):
            conn.execute("INSERT INTO notifications(outbox_id,user_id,message,created_at) VALUES (?,?,?,?)",
                         (job["id"], self.uid["m1"], "partial", "now"))   # must be rolled back
            raise RuntimeError("smtp down")

        with tx(self.db):
            self.db.execute("INSERT INTO outbox(type,payload,created_at) VALUES ('boom','{}','now')")
        kw = dict(handlers={"boom": boom}, max_attempts=3, backoff=10)
        worker.run_once(self.db, now=100, **kw)
        job = dict(self.db.execute("SELECT * FROM outbox").fetchone())
        self.assertEqual((job["status"], job["attempts"], job["next_attempt_at"]), ("pending", 1, 110))
        self.assertEqual(worker.run_once(self.db, now=105, **kw), 0)    # not due yet
        worker.run_once(self.db, now=110, **kw)
        worker.run_once(self.db, now=200, **kw)
        job = dict(self.db.execute("SELECT * FROM outbox").fetchone())
        self.assertEqual((job["status"], job["attempts"]), ("failed", 3))
        self.assertIn("smtp down", job["last_error"])
        self.assertEqual(self.count("notifications"), 0)   # failed attempts left no side effects


class ListingAndPagination(ApiTestCase):
    def test_cursor_pagination_has_no_gaps_or_duplicates_and_filters_server_side(self):
        ids = [self.make_item(priority="urgent" if i % 3 == 0 else "low", title=f"item {i}") for i in range(120)]
        c, h = self.app.test_client(), self.login("m1")
        seen, cursor = [], None
        while True:
            url = "/api/items?limit=50" + (f"&cursor={cursor}" if cursor else "")
            data = c.get(url, headers=h).get_json()
            seen += [i["id"] for i in data["items"]]
            cursor = data["next_cursor"]
            if not cursor:
                break
        self.assertEqual(seen, sorted(ids, reverse=True))
        urgent = c.get("/api/items?priority=urgent&limit=100", headers=h).get_json()["items"]
        self.assertEqual(len(urgent), 40)
        found = c.get("/api/items?q=item 11&limit=100", headers=h).get_json()["items"]
        self.assertTrue(found and all("item 11" in i["title"] for i in found))

    def test_dashboard_views(self):
        self.make_item(priority="urgent", title="u1")                           # unassigned urgent
        self.make_item(status="in_progress", assignee="m1", title="mine")
        self.make_item(status="awaiting_approval", assignee="m1", title="appr")
        self.make_item(status="awaiting_approval", assignee="lead_a", title="own appr")
        c = self.app.test_client()
        self.assertEqual(c.get("/api/dashboard", headers=self.login("m1")).get_json(),
                         {"assigned_to_me": 2, "unassigned_urgent": 1, "awaiting_my_approval": 0})
        self.assertEqual(c.get("/api/dashboard", headers=self.login("lead_a")).get_json()["awaiting_my_approval"], 1)
        titles = [i["title"] for i in c.get("/api/items?view=awaiting_my_approval",
                                            headers=self.login("lead_a")).get_json()["items"]]
        self.assertEqual(titles, ["appr"])


if __name__ == "__main__":
    unittest.main()
