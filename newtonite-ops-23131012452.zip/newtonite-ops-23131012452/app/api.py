import hashlib
import json

from flask import Blueprint, current_app, g, jsonify, request

from . import auth, items as svc
from .db import connect, tx
from .util import ApiError, utcnow

bp = Blueprint("api", __name__, url_prefix="/api")


def conn():
    if "conn" not in g:
        g.conn = connect(current_app.config["DB_PATH"])
    return g.conn


@bp.teardown_request
def _close(_exc):
    c = g.pop("conn", None)
    if c:
        c.close()


def current_user():
    header = request.headers.get("Authorization", "")
    user = auth.user_for_token(conn(), header[7:]) if header.startswith("Bearer ") else None
    if not user:
        raise ApiError(401, "unauthenticated", "Log in and send 'Authorization: Bearer <token>'")
    return user


def body():
    data = request.get_json(silent=True)
    if data is None:
        return {}
    if not isinstance(data, dict):
        raise ApiError(400, "bad_request", "JSON object expected")
    return data


def run_write(user, fn):
    """Runs fn(conn) in ONE transaction. If the client sent an Idempotency-Key, the stored
    response is replayed on repeats; the key row is written in the same transaction as the
    change, so 'did it happen?' and 'is the key stored?' can never disagree."""
    c = conn()
    key = request.headers.get("Idempotency-Key")
    if key is not None and not (1 <= len(key) <= 200):
        raise ApiError(400, "bad_request", "Idempotency-Key must be 1-200 characters")
    fingerprint = hashlib.sha256(f"{request.method} {request.path}\n".encode() + request.get_data()).hexdigest()
    with tx(c):
        if key:
            row = c.execute("SELECT fingerprint,status_code,response FROM idempotency_keys "
                            "WHERE user_id=? AND key=?", (user["id"], key)).fetchone()
            if row:
                if row["fingerprint"] != fingerprint:
                    raise ApiError(422, "idempotency_key_reuse", "This key was already used for a different request")
                resp = jsonify(json.loads(row["response"]))
                resp.status_code = row["status_code"]
                resp.headers["Idempotent-Replay"] = "true"
                return resp
        status, payload = fn(c)
        if key:
            c.execute("INSERT INTO idempotency_keys VALUES (?,?,?,?,?,?)",
                      (user["id"], key, fingerprint, status, json.dumps(payload), utcnow()))
    resp = jsonify(payload)
    resp.status_code = status
    return resp


# ---------- auth ----------
@bp.post("/login")
def login():
    data = body()
    token, user = auth.login(conn(), data.get("username"), data.get("password"))
    return jsonify({"token": token, "user": user})


@bp.get("/me")
def me():
    return jsonify(current_user())


# ---------- items ----------
@bp.get("/dashboard")
def dashboard():
    return jsonify(svc.dashboard(conn(), current_user()))


@bp.get("/items")
def list_items():
    return jsonify(svc.list_items(conn(), current_user(), request.args))


@bp.post("/items")
def create_item():
    user, data = current_user(), body()
    return run_write(user, lambda c: svc.create_item(c, user, data))


@bp.get("/items/<int:item_id>")
def get_item(item_id):
    return jsonify(svc.get_item(conn(), current_user(), item_id))


@bp.patch("/items/<int:item_id>")
def update_item(item_id):
    user, data = current_user(), body()
    return run_write(user, lambda c: svc.update_item(c, user, item_id, data))


@bp.post("/items/<int:item_id>/claim")
def claim(item_id):
    user = current_user()
    return run_write(user, lambda c: svc.claim(c, user, item_id))


@bp.post("/items/<int:item_id>/assign")
def assign(item_id):
    user, data = current_user(), body()
    return run_write(user, lambda c: svc.assign(c, user, item_id, data))


@bp.post("/items/<int:item_id>/transition")
def transition(item_id):
    user, data = current_user(), body()
    return run_write(user, lambda c: svc.transition(c, user, item_id, data))


@bp.post("/items/<int:item_id>/comments")
def comment(item_id):
    user, data = current_user(), body()
    return run_write(user, lambda c: svc.add_comment(c, user, item_id, data))


@bp.get("/items/<int:item_id>/activity")
def activity(item_id):
    return jsonify(svc.activity(conn(), current_user(), item_id, request.args))


@bp.get("/notifications")
def notifications():
    user = current_user()
    rows = conn().execute("SELECT id,message,created_at FROM notifications WHERE user_id=? "
                          "ORDER BY id DESC LIMIT 50", (user["id"],)).fetchall()
    return jsonify([dict(r) for r in rows])
