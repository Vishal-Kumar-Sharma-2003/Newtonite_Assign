import contextlib
import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, username TEXT UNIQUE NOT NULL, name TEXT NOT NULL, password_hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS teams(id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL);
CREATE TABLE IF NOT EXISTS memberships(
  user_id INTEGER NOT NULL REFERENCES users(id),
  team_id INTEGER NOT NULL REFERENCES teams(id),
  role TEXT NOT NULL CHECK(role IN ('viewer','member','lead','admin')),
  PRIMARY KEY(user_id, team_id));
CREATE TABLE IF NOT EXISTS tokens(
  token_hash TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id), expires_at REAL NOT NULL);

CREATE TABLE IF NOT EXISTS work_items(
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  type TEXT NOT NULL CHECK(type IN ('incident','customer_issue','payment','compliance','task')),
  priority TEXT NOT NULL CHECK(priority IN ('low','medium','high','urgent')),
  status TEXT NOT NULL CHECK(status IN ('open','in_progress','awaiting_approval','resolved','closed')),
  team_id INTEGER NOT NULL REFERENCES teams(id),
  assignee_id INTEGER REFERENCES users(id),
  created_by INTEGER NOT NULL REFERENCES users(id),
  due_date TEXT,
  version INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL);
-- Every list is scoped by team and paginated by id (keyset), so these cover the hot paths.
CREATE INDEX IF NOT EXISTS idx_items_team        ON work_items(team_id, id DESC);
CREATE INDEX IF NOT EXISTS idx_items_team_status ON work_items(team_id, status, id DESC);
CREATE INDEX IF NOT EXISTS idx_items_assignee    ON work_items(assignee_id, status, id DESC);
CREATE INDEX IF NOT EXISTS idx_items_unassigned_urgent
  ON work_items(team_id, id DESC) WHERE assignee_id IS NULL AND priority = 'urgent';

CREATE TABLE IF NOT EXISTS activity_events(
  id INTEGER PRIMARY KEY,
  item_id INTEGER NOT NULL REFERENCES work_items(id),
  actor_id INTEGER NOT NULL REFERENCES users(id),
  kind TEXT NOT NULL,
  detail TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_activity_item ON activity_events(item_id, id DESC);

CREATE TABLE IF NOT EXISTS idempotency_keys(
  user_id INTEGER NOT NULL, key TEXT NOT NULL, fingerprint TEXT NOT NULL,
  status_code INTEGER NOT NULL, response TEXT NOT NULL, created_at TEXT NOT NULL,
  PRIMARY KEY(user_id, key));

CREATE TABLE IF NOT EXISTS outbox(
  id INTEGER PRIMARY KEY,
  type TEXT NOT NULL,
  payload TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','done','failed')),
  attempts INTEGER NOT NULL DEFAULT 0,
  next_attempt_at REAL NOT NULL DEFAULT 0,
  last_error TEXT,
  created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS idx_outbox_due ON outbox(status, next_attempt_at);

CREATE TABLE IF NOT EXISTS notifications(
  id INTEGER PRIMARY KEY,
  outbox_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL REFERENCES users(id),
  message TEXT NOT NULL,
  created_at TEXT NOT NULL,
  UNIQUE(outbox_id, user_id));   -- makes the worker handler idempotent
"""


def connect(path):
    # isolation_level=None -> autocommit; we open transactions explicitly with tx().
    conn = sqlite3.connect(path, timeout=15, isolation_level=None)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_db(path):
    conn = connect(path)
    try:
        conn.executescript(SCHEMA)
    finally:
        conn.close()


@contextlib.contextmanager
def tx(conn):
    """One write transaction. BEGIN IMMEDIATE takes the write lock up front, so
    read-check-write sequences inside cannot interleave with another writer."""
    conn.execute("BEGIN IMMEDIATE")
    try:
        yield conn
    except BaseException:
        conn.execute("ROLLBACK")
        raise
    else:
        conn.execute("COMMIT")
