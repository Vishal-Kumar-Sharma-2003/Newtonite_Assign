"""Service layer. Every function here runs INSIDE a transaction opened by the caller
(api.run_write), so the item change, its activity event and any outbox job commit
or roll back together."""
import json
from datetime import date

from .perms import RANK, authorize
from .util import ApiError, utcnow

TYPES = ("incident", "customer_issue", "payment", "compliance", "task")
PRIORITIES = ("low", "medium", "high", "urgent")
STATUSES = ("open", "in_progress", "awaiting_approval", "resolved", "closed")
EDITABLE = ("title", "description", "type", "priority", "due_date")

# (from, to) -> minimum role in the item's team. Anything not listed is rejected.
TRANSITIONS = {
    ("open", "in_progress"): "member",
    ("in_progress", "awaiting_approval"): "member",
    ("awaiting_approval", "resolved"): "lead",      # the approval step
    ("awaiting_approval", "in_progress"): "lead",    # approval rejected
    ("resolved", "closed"): "lead",
    ("resolved", "in_progress"): "lead",             # reopen
}

_SELECT = ("SELECT i.*, u.name AS assignee_name FROM work_items i "
           "LEFT JOIN users u ON u.id = i.assignee_id ")


# ---------- helpers ----------
def load(conn, item_id):
    row = conn.execute(_SELECT + "WHERE i.id=?", (item_id,)).fetchone()
    if not row:
        raise ApiError(404, "not_found", "Work item not found")
    return dict(row)


def log_event(conn, item_id, actor_id, kind, detail):
    conn.execute("INSERT INTO activity_events(item_id,actor_id,kind,detail,created_at) VALUES (?,?,?,?,?)",
                 (item_id, actor_id, kind, json.dumps(detail), utcnow()))


def enqueue(conn, job_type, payload):
    conn.execute("INSERT INTO outbox(type,payload,created_at) VALUES (?,?,?)",
                 (job_type, json.dumps(payload), utcnow()))


def _conflict(conn, item_id, code, message):
    raise ApiError(409, code, message, {"current": load(conn, item_id)})


def _version(data):
    v = data.get("version")
    if not isinstance(v, int) or isinstance(v, bool):
        raise ApiError(400, "version_required", "Send the item's current integer 'version'")
    return v


def _int(data, key):
    v = data.get(key)
    if not isinstance(v, int) or isinstance(v, bool):
        raise ApiError(400, "bad_request", f"'{key}' must be an integer")
    return v


def _clean(field, value):
    if field == "title":
        if not isinstance(value, str) or not value.strip() or len(value) > 200:
            raise ApiError(400, "bad_request", "title must be 1-200 characters")
        return value.strip()
    if field == "description":
        if not isinstance(value, str) or len(value) > 5000:
            raise ApiError(400, "bad_request", "description must be text up to 5000 characters")
        return value
    if field == "type" and value not in TYPES:
        raise ApiError(400, "bad_request", f"type must be one of {TYPES}")
    if field == "priority" and value not in PRIORITIES:
        raise ApiError(400, "bad_request", f"priority must be one of {PRIORITIES}")
    if field == "due_date":
        if value is None:
            return None
        try:
            return date.fromisoformat(value).isoformat()
        except (TypeError, ValueError):
            raise ApiError(400, "bad_request", "due_date must be YYYY-MM-DD or null")
    return value


def _check_assignable(conn, team_id, user_id):
    role = conn.execute("SELECT role FROM memberships WHERE user_id=? AND team_id=?",
                        (user_id, team_id)).fetchone()
    if not role or RANK[role["role"]] < RANK["member"]:
        raise ApiError(422, "bad_assignee", "Assignee must be a member (or above) of the item's team")


def _bump(conn, item, version, changes):
    """Optimistic lock: the UPDATE only matches if nobody changed the row since the client read it."""
    sets = ", ".join(f"{k}=?" for k in changes)   # keys are internal constants, never user input
    cur = conn.execute(
        f"UPDATE work_items SET {sets}, version=version+1, updated_at=? WHERE id=? AND version=?",
        [*changes.values(), utcnow(), item["id"], version])
    if cur.rowcount == 0:
        _conflict(conn, item["id"], "version_conflict",
                  "This item changed since you loaded it. Reload and try again.")


# ---------- commands ----------
def create_item(conn, user, data):
    team_id = _int(data, "team_id")
    authorize(user, team_id, "create")
    fields = {
        "title": _clean("title", data.get("title")),
        "description": _clean("description", data.get("description", "")),
        "type": _clean("type", data.get("type", "task")),
        "priority": _clean("priority", data.get("priority", "medium")),
        "due_date": _clean("due_date", data.get("due_date")),
    }
    assignee_id = data.get("assignee_id")
    if assignee_id is not None:
        authorize(user, team_id, "reassign")          # only leads may assign at creation
        _check_assignable(conn, team_id, _int(data, "assignee_id"))
    now = utcnow()
    cur = conn.execute(
        "INSERT INTO work_items(title,description,type,priority,status,team_id,assignee_id,created_by,"
        "due_date,version,created_at,updated_at) VALUES (?,?,?,?, 'open',?,?,?,?,1,?,?)",
        (fields["title"], fields["description"], fields["type"], fields["priority"], team_id,
         assignee_id, user["id"], fields["due_date"], now, now))
    item_id = cur.lastrowid
    log_event(conn, item_id, user["id"], "created", {"title": fields["title"], "priority": fields["priority"]})
    if assignee_id is not None:
        log_event(conn, item_id, user["id"], "assignee_changed", {"from": None, "to": assignee_id})
        enqueue(conn, "notify_assignee", {"item_id": item_id, "user_id": assignee_id,
                                          "message": f"You were assigned: {fields['title']}"})
    return 201, load(conn, item_id)


def update_item(conn, user, item_id, data):
    version = _version(data)
    item = load(conn, item_id)
    authorize(user, item["team_id"], "edit")
    changes = {}
    for f in EDITABLE:
        if f in data:
            new = _clean(f, data[f])
            if new != item[f]:
                changes[f] = new
    if not changes:
        if item["version"] != version:
            _conflict(conn, item_id, "version_conflict", "This item changed since you loaded it.")
        return 200, item
    _bump(conn, item, version, changes)
    for f, new in changes.items():
        kind = "priority_changed" if f == "priority" else "field_changed"
        log_event(conn, item_id, user["id"], kind, {"field": f, "from": item[f], "to": new})
    return 200, load(conn, item_id)


def claim(conn, user, item_id):
    item = load(conn, item_id)
    authorize(user, item["team_id"], "claim")
    # Atomic compare-and-set: only one concurrent claimer can match "assignee IS NULL".
    cur = conn.execute(
        "UPDATE work_items SET assignee_id=?, status='in_progress', version=version+1, updated_at=? "
        "WHERE id=? AND assignee_id IS NULL AND status='open'",
        (user["id"], utcnow(), item_id))
    if cur.rowcount == 0:
        fresh = load(conn, item_id)
        if fresh["assignee_id"] is not None:
            _conflict(conn, item_id, "already_claimed", "Someone else already claimed this item")
        _conflict(conn, item_id, "not_claimable", "Only open, unassigned items can be claimed")
    log_event(conn, item_id, user["id"], "assignee_changed", {"from": None, "to": user["id"]})
    log_event(conn, item_id, user["id"], "status_changed", {"from": "open", "to": "in_progress"})
    return 200, load(conn, item_id)


def assign(conn, user, item_id, data):
    version = _version(data)
    item = load(conn, item_id)
    authorize(user, item["team_id"], "reassign")
    if "assignee_id" not in data:
        raise ApiError(400, "bad_request", "assignee_id required (or null to unassign)")
    new = data["assignee_id"]
    if new is not None:
        _check_assignable(conn, item["team_id"], _int(data, "assignee_id"))
    if item["status"] in ("resolved", "closed"):
        raise ApiError(409, "invalid_state", "Cannot reassign a resolved or closed item")
    _bump(conn, item, version, {"assignee_id": new})
    log_event(conn, item_id, user["id"], "assignee_changed", {"from": item["assignee_id"], "to": new})
    if new is not None:
        enqueue(conn, "notify_assignee", {"item_id": item_id, "user_id": new,
                                          "message": f"You were assigned: {item['title']}"})
    return 200, load(conn, item_id)


def transition(conn, user, item_id, data):
    version = _version(data)
    to = data.get("to")
    if to not in STATUSES:
        raise ApiError(400, "bad_request", f"'to' must be one of {STATUSES}")
    item = load(conn, item_id)
    role = authorize(user, item["team_id"], "transition")
    if item["version"] != version:
        _conflict(conn, item_id, "version_conflict", "This item changed since you loaded it. Reload and try again.")
    need = TRANSITIONS.get((item["status"], to))
    if need is None:
        raise ApiError(409, "invalid_transition", f"Cannot move from {item['status']} to {to}",
                       {"current": item})
    if RANK[role] < RANK[need]:
        raise ApiError(403, "forbidden", f"Moving to {to} needs the {need} role in this team")
    if role == "member" and item["assignee_id"] != user["id"]:
        raise ApiError(403, "not_assignee", "Members can only move items assigned to them")
    if (item["status"], to) == ("open", "in_progress") and item["assignee_id"] is None:
        raise ApiError(409, "needs_assignee", "Assign or claim the item before starting it")
    if (item["status"], to) == ("awaiting_approval", "resolved") and item["assignee_id"] == user["id"]:
        raise ApiError(403, "self_approval", "You cannot approve an item assigned to you")
    _bump(conn, item, version, {"status": to})
    log_event(conn, item_id, user["id"], "status_changed", {"from": item["status"], "to": to})
    if to == "awaiting_approval":
        enqueue(conn, "notify_approvers", {"item_id": item_id, "team_id": item["team_id"],
                                           "message": f"Needs approval: {item['title']}"})
    return 200, load(conn, item_id)


def add_comment(conn, user, item_id, data):
    item = load(conn, item_id)
    authorize(user, item["team_id"], "comment")
    body = data.get("body")
    if not isinstance(body, str) or not body.strip() or len(body) > 2000:
        raise ApiError(400, "bad_request", "comment body must be 1-2000 characters")
    log_event(conn, item_id, user["id"], "comment", {"body": body.strip()})
    return 201, {"ok": True}


# ---------- queries ----------
def get_item(conn, user, item_id):
    item = load(conn, item_id)
    authorize(user, item["team_id"], "read")
    return item


def _view_clause(view, user):
    if view is None or view == "all":
        return "", []
    if view == "assigned_to_me":
        return " AND i.assignee_id=? AND i.status NOT IN ('resolved','closed')", [user["id"]]
    if view == "unassigned_urgent":
        return " AND i.assignee_id IS NULL AND i.priority='urgent' AND i.status='open'", []
    if view == "awaiting_my_approval":
        approver_teams = [t for t, r in user["memberships"].items() if RANK[r] >= RANK["lead"]]
        if not approver_teams:
            return " AND 0", []
        marks = ",".join("?" * len(approver_teams))
        return (f" AND i.status='awaiting_approval' AND i.team_id IN ({marks})"
                " AND (i.assignee_id IS NULL OR i.assignee_id != ?)"), [*approver_teams, user["id"]]
    raise ApiError(400, "bad_request", "unknown view")


def list_items(conn, user, args):
    team_ids = list(user["memberships"])
    if "team_id" in args:
        try:
            tid = int(args["team_id"])
        except ValueError:
            raise ApiError(400, "bad_request", "team_id must be an integer")
        authorize(user, tid, "read")
        team_ids = [tid]
    if not team_ids:
        return {"items": [], "next_cursor": None}
    try:
        limit = min(max(int(args.get("limit", 25)), 1), 100)
        cursor = int(args["cursor"]) if args.get("cursor") else None
    except ValueError:
        raise ApiError(400, "bad_request", "limit/cursor must be integers")

    sql = _SELECT + f"WHERE i.team_id IN ({','.join('?' * len(team_ids))})"   # authorization scope
    params = list(team_ids)
    for col, allowed in (("status", STATUSES), ("priority", PRIORITIES), ("type", TYPES)):
        if args.get(col):
            if args[col] not in allowed:
                raise ApiError(400, "bad_request", f"invalid {col}")
            sql += f" AND i.{col}=?"
            params.append(args[col])
    if args.get("assignee"):
        sql += " AND i.assignee_id=?"
        params.append(user["id"] if args["assignee"] == "me" else int(args["assignee"]))
    if args.get("q"):
        like = "%" + args["q"].replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_") + "%"
        sql += " AND (i.title LIKE ? ESCAPE '\\' OR i.description LIKE ? ESCAPE '\\')"
        params += [like, like]
    extra, p = _view_clause(args.get("view"), user)
    sql += extra
    params += p
    if cursor is not None:
        sql += " AND i.id < ?"
        params.append(cursor)
    sql += " ORDER BY i.id DESC LIMIT ?"
    params.append(limit + 1)
    rows = [dict(r) for r in conn.execute(sql, params).fetchall()]
    next_cursor = rows[limit - 1]["id"] if len(rows) > limit else None
    return {"items": rows[:limit], "next_cursor": next_cursor}


def dashboard(conn, user):
    out = {}
    for view in ("assigned_to_me", "unassigned_urgent", "awaiting_my_approval"):
        team_ids = list(user["memberships"])
        if not team_ids:
            out[view] = 0
            continue
        extra, p = _view_clause(view, user)
        sql = (f"SELECT COUNT(*) AS n FROM work_items i WHERE i.team_id IN ({','.join('?' * len(team_ids))})" + extra)
        out[view] = conn.execute(sql, [*team_ids, *p]).fetchone()["n"]
    return out


def activity(conn, user, item_id, args):
    item = load(conn, item_id)
    authorize(user, item["team_id"], "read")
    try:
        limit = min(max(int(args.get("limit", 50)), 1), 200)
        cursor = int(args["cursor"]) if args.get("cursor") else None
    except ValueError:
        raise ApiError(400, "bad_request", "limit/cursor must be integers")
    sql = ("SELECT e.id, e.kind, e.detail, e.created_at, u.name AS actor FROM activity_events e "
           "JOIN users u ON u.id=e.actor_id WHERE e.item_id=?")
    params = [item_id]
    if cursor is not None:
        sql += " AND e.id < ?"
        params.append(cursor)
    sql += " ORDER BY e.id DESC LIMIT ?"
    params.append(limit + 1)
    rows = conn.execute(sql, params).fetchall()
    events = [{**dict(r), "detail": json.loads(r["detail"])} for r in rows[:limit]]
    return {"events": events, "next_cursor": rows[limit - 1]["id"] if len(rows) > limit else None}
