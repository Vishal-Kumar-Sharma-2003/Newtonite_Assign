import hashlib
import secrets
import time

from werkzeug.security import check_password_hash

from .util import ApiError

TOKEN_TTL = 12 * 3600


def _h(token):
    return hashlib.sha256(token.encode()).hexdigest()


def login(conn, username, password):
    row = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
    if not row or not check_password_hash(row["password_hash"], password or ""):
        raise ApiError(401, "bad_credentials", "Invalid username or password")
    token = secrets.token_urlsafe(32)
    conn.execute("INSERT INTO tokens VALUES (?,?,?)", (_h(token), row["id"], time.time() + TOKEN_TTL))
    return token, load_user(conn, row["id"])


def load_user(conn, user_id):
    u = conn.execute("SELECT id, username, name FROM users WHERE id=?", (user_id,)).fetchone()
    if not u:
        return None
    rows = conn.execute(
        "SELECT m.team_id, m.role, t.name FROM memberships m JOIN teams t ON t.id=m.team_id WHERE m.user_id=?",
        (user_id,)).fetchall()
    user = dict(u)
    user["memberships"] = {r["team_id"]: r["role"] for r in rows}
    user["teams"] = [{"team_id": r["team_id"], "name": r["name"], "role": r["role"]} for r in rows]
    return user


def user_for_token(conn, token):
    row = conn.execute("SELECT user_id FROM tokens WHERE token_hash=? AND expires_at>?",
                       (_h(token), time.time())).fetchone()
    return load_user(conn, row["user_id"]) if row else None
