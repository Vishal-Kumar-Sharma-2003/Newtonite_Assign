"""Seed demo data: 4 teams, 11 users in different roles, ~5,000 items (proves pagination).
Usage: python -m app.seed [--if-empty] [--items N]   (all demo passwords: password123)"""
import argparse
import json
import os
import random

from werkzeug.security import generate_password_hash

from .db import connect, init_db, tx
from .util import utcnow

TEAMS = ["Payments", "Compliance", "Support", "Platform"]
# username -> (display name, {team: role})
USERS = {
    "admin":        ("Asha Admin",   {t: "admin" for t in TEAMS}),
    "lead_pay":     ("Lakshmi Pay",  {"Payments": "lead"}),
    "lead_comp":    ("Lokesh Comp",  {"Compliance": "lead"}),
    "lead_sup":     ("Leela Support", {"Support": "lead"}),
    "lead_plat":    ("Lavanya Plat", {"Platform": "lead"}),
    "member_pay1":  ("Manav Pay",    {"Payments": "member"}),
    "member_pay2":  ("Meera Pay",    {"Payments": "member"}),
    "member_comp":  ("Mohit Comp",   {"Compliance": "member"}),
    "member_sup":   ("Maya Support", {"Support": "member", "Platform": "member"}),
    "viewer_pay":   ("Vikram View",  {"Payments": "viewer"}),
    "multi":        ("Mina Multi",   {"Support": "lead", "Payments": "viewer"}),
}
VERBS = ["Investigate", "Fix", "Review", "Escalate", "Reconcile", "Follow up on", "Audit", "Retry"]
NOUNS = ["failed payout", "KYC backlog", "duplicate charge", "chargeback", "login errors",
         "refund delay", "settlement mismatch", "API timeout", "compliance report", "customer complaint"]
TYPES = ["incident", "customer_issue", "payment", "compliance", "task"]
PRIORITIES = ["low", "medium", "high", "urgent"]
STATUSES = ["open"] * 4 + ["in_progress"] * 3 + ["awaiting_approval", "resolved", "closed"]


def seed(conn, n_items=5000):
    rnd = random.Random(42)
    pw = generate_password_hash("password123")
    with tx(conn):
        team_ids = {}
        for name in TEAMS:
            team_ids[name] = conn.execute("INSERT INTO teams(name) VALUES (?)", (name,)).lastrowid
        uid = {}
        for username, (name, roles) in USERS.items():
            uid[username] = conn.execute("INSERT INTO users(username,name,password_hash) VALUES (?,?,?)",
                                         (username, name, pw)).lastrowid
            for team, role in roles.items():
                conn.execute("INSERT INTO memberships VALUES (?,?,?)", (uid[username], team_ids[team], role))
        # who can be assignee / creator per team
        workers = {t: [uid[u] for u, (_, r) in USERS.items() if r.get(t) in ("member", "lead", "admin")] for t in TEAMS}
        now = utcnow()
        item_rows, event_rows = [], []
        for i in range(1, n_items + 1):
            team = rnd.choice(TEAMS)
            status = rnd.choice(STATUSES)
            priority = rnd.choices(PRIORITIES, weights=[3, 4, 3, 2])[0]
            # open items are mostly unassigned so the "unassigned urgent" view has data
            assignee = None if status == "open" and rnd.random() < 0.7 else rnd.choice(workers[team])
            if status != "open" and assignee is None:
                assignee = rnd.choice(workers[team])
            title = f"{rnd.choice(VERBS)} {rnd.choice(NOUNS)} #{i}"
            creator = rnd.choice(workers[team])
            item_rows.append((i, title, "Seeded demo item.", rnd.choice(TYPES), priority, status,
                              team_ids[team], assignee, creator, None, 1, now, now))
            event_rows.append((i, creator, "created", json.dumps({"title": title, "priority": priority}), now))
        conn.executemany("INSERT INTO work_items VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)", item_rows)
        conn.executemany("INSERT INTO activity_events(item_id,actor_id,kind,detail,created_at) VALUES (?,?,?,?,?)",
                         event_rows)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--if-empty", action="store_true")
    ap.add_argument("--items", type=int, default=5000)
    a = ap.parse_args()
    path = os.environ.get("OPS_DB", "ops.db")
    init_db(path)
    c = connect(path)
    if a.if_empty and c.execute("SELECT COUNT(*) FROM users").fetchone()[0]:
        print("already seeded, skipping")
    else:
        seed(c, a.items)
        print(f"seeded {a.items} items into {path}")
