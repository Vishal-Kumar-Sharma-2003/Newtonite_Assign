"""Outbox worker. Jobs are written in the same transaction as the change that caused
them; this process delivers them with retries, exponential backoff and a max-attempt cap."""
import argparse
import json
import time

from .db import connect, init_db, tx
from .util import utcnow


def _insert_notification(conn, job, user_id, message):
    # UNIQUE(outbox_id, user_id) + INSERT OR IGNORE => running this twice is harmless.
    conn.execute("INSERT OR IGNORE INTO notifications(outbox_id,user_id,message,created_at) VALUES (?,?,?,?)",
                 (job["id"], user_id, message, utcnow()))


def notify_assignee(conn, job):
    p = json.loads(job["payload"])
    _insert_notification(conn, job, p["user_id"], p["message"])


def notify_approvers(conn, job):
    p = json.loads(job["payload"])
    leads = conn.execute("SELECT user_id FROM memberships WHERE team_id=? AND role IN ('lead','admin')",
                         (p["team_id"],)).fetchall()
    for r in leads:
        _insert_notification(conn, job, r["user_id"], p["message"])


HANDLERS = {"notify_assignee": notify_assignee, "notify_approvers": notify_approvers}


def run_once(conn, now=None, max_attempts=5, backoff=2.0, handlers=None, limit=20):
    """Process due jobs. A failing handler's side effects are rolled back (savepoint),
    then the job is rescheduled, or marked failed after max_attempts."""
    handlers = handlers or HANDLERS
    now = time.time() if now is None else now
    done = 0
    with tx(conn):
        jobs = conn.execute("SELECT * FROM outbox WHERE status='pending' AND next_attempt_at<=? "
                            "ORDER BY id LIMIT ?", (now, limit)).fetchall()
        for job in jobs:
            conn.execute("SAVEPOINT job")
            try:
                handlers[job["type"]](conn, job)
                conn.execute("RELEASE job")
                conn.execute("UPDATE outbox SET status='done', attempts=attempts+1, last_error=NULL WHERE id=?",
                             (job["id"],))
                done += 1
            except Exception as exc:  # noqa: BLE001 - any handler failure means retry
                conn.execute("ROLLBACK TO job")
                conn.execute("RELEASE job")
                attempts = job["attempts"] + 1
                if attempts >= max_attempts:
                    conn.execute("UPDATE outbox SET status='failed', attempts=?, last_error=? WHERE id=?",
                                 (attempts, repr(exc), job["id"]))
                else:
                    conn.execute("UPDATE outbox SET attempts=?, last_error=?, next_attempt_at=? WHERE id=?",
                                 (attempts, repr(exc), now + backoff * 2 ** (attempts - 1), job["id"]))
    return done


if __name__ == "__main__":
    import os
    ap = argparse.ArgumentParser()
    ap.add_argument("--loop", action="store_true", help="keep polling every second")
    args = ap.parse_args()
    path = os.environ.get("OPS_DB", "ops.db")
    init_db(path)
    c = connect(path)
    while True:
        n = run_once(c)
        if n:
            print(f"processed {n} job(s)", flush=True)
        if not args.loop:
            break
        time.sleep(1)
