import os

from flask import Flask, jsonify
from werkzeug.exceptions import HTTPException

from .db import init_db
from .util import ApiError


def create_app(db_path=None):
    app = Flask(__name__, static_folder="static", static_url_path="/static")
    app.config["DB_PATH"] = db_path or os.environ.get("OPS_DB", "ops.db")
    init_db(app.config["DB_PATH"])

    from .api import bp
    app.register_blueprint(bp)

    @app.get("/")
    def index():
        return app.send_static_file("index.html")

    @app.errorhandler(ApiError)
    def api_error(e):
        resp = jsonify({"error": {"code": e.code, "message": e.message}, **e.extra})
        resp.status_code = e.status
        return resp

    @app.errorhandler(HTTPException)
    def http_error(e):
        resp = jsonify({"error": {"code": e.name.lower().replace(" ", "_"), "message": e.description}})
        resp.status_code = e.code
        return resp

    return app
