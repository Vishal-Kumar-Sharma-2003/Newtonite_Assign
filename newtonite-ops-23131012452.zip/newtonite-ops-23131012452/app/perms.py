"""The single place that decides who may do what, scoped per team."""
from .util import ApiError

RANK = {"viewer": 1, "member": 2, "lead": 3, "admin": 4}

# role x action matrix (minimum role in the item's team)
ACTION_MIN_ROLE = {
    "read": "viewer",
    "create": "member",
    "edit": "member",
    "claim": "member",
    "comment": "member",
    "transition": "member",   # individual transitions can demand more, see items.TRANSITIONS
    "reassign": "lead",
}


def authorize(user, team_id, action):
    """Return the user's role in team_id, or raise 403. Called by every endpoint
    through the service layer -- never only in the UI."""
    role = user["memberships"].get(team_id)
    if role is None or RANK[role] < RANK[ACTION_MIN_ROLE[action]]:
        raise ApiError(403, "forbidden", f"You are not allowed to {action} in this team")
    return role
