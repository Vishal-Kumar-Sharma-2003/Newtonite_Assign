from datetime import datetime, timezone


class ApiError(Exception):
    """Raised anywhere in the service layer; rendered as JSON by the app."""

    def __init__(self, status, code, message, extra=None):
        super().__init__(message)
        self.status, self.code, self.message, self.extra = status, code, message, extra or {}


def utcnow():
    return datetime.now(timezone.utc).isoformat(timespec="microseconds")
